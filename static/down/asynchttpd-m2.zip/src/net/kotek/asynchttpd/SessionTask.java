package net.kotek.asynchttpd;

import java.io.File;
import java.io.IOException;
import java.lang.reflect.Method;
import java.nio.ByteBuffer;
import java.nio.MappedByteBuffer;
import java.nio.channels.SocketChannel;
import java.nio.channels.spi.AbstractSelectableChannel;
import java.nio.charset.Charset;
import java.nio.charset.CharsetDecoder;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import kilim.Task;
import kilim.pausable;

/** this task is started to handle new connections to server and sessions*/
public class SessionTask extends Task{
	
	List<Extension> extensions;
	
	/**
	 * Some HTTP response status codes
	 */
	public static final String
		HTTP_OK = "200 OK",
		HTTP_REDIRECT = "301 Moved Permanently",
		HTTP_FORBIDDEN = "403 Forbidden",
		HTTP_NOTFOUND = "404 Not Found",
		HTTP_BADREQUEST = "400 Bad Request",
		HTTP_INTERNALERROR = "500 Internal Server Error",
		HTTP_NOTIMPLEMENTED = "501 Not Implemented";

	/**
	 * Common mime types for dynamic content
	 */
	public static final String
		MIME_PLAINTEXT = "text/plain",
		MIME_HTML = "text/html",
		MIME_DEFAULT_BINARY = "application/octet-stream";


	private static CharsetDecoder headDecoder = Charset.forName( "ISO-8859-1" ).newDecoder();
	private SocketChannel sc;
	
	/** time when last data were received from socket, used for timeout */
	private long lastData = 0;

	private String request;

	private String[] requests;

	private String uri;

	private String method;

	private String protocol;

	private Method closeMethod;

	private boolean headerSend = false;

	private Map<String,String> requestFields;
	
	private StringBuilder headerToSend = new StringBuilder();

	SessionTask(SocketChannel sc) throws IOException {
		this.sc = sc;
		sc.configureBlocking(false);
		extensions = AsyncHttpd.extensions; // TODO non static initialization
		try{
			closeMethod = AbstractSelectableChannel.class.getDeclaredMethod("implCloseSelectableChannel");
			closeMethod.setAccessible(true);
		}catch (Throwable ee){
			AsyncHttpd.log.error("Can not get non blocking close method on SocketChannel, not fatal, but server will be much slower.",ee);
			closeMethod = null;
		}

	}
	
	@pausable @Override
	public void execute() throws Exception {
		try{
			while(sc.isConnectionPending())
				yield();
			request = readRequest();
			if(AsyncHttpd.log.isTraceEnabled())
				AsyncHttpd.log.trace(this.toString()+" request head: "+request);			
			//split to array and parse header
			requests = Utils.splitByWholeSeparator(request, Const.RN);
			
			if(requests.length<1){
				sendError( HTTP_BADREQUEST, "BAD REQUEST: Syntax error. Usage: GET /example/file.html" );
				return;
			}
			
			//split first line and get parameters
			String[] firstLine = Utils.split(requests[0], " ");
			if ( firstLine.length!=3){
				sendError( HTTP_BADREQUEST, "BAD REQUEST: Syntax error. Usage: GET /example/file.html" );
				return;
			}
			method = firstLine[0];		
			uri = firstLine[1];
			protocol = firstLine[2];
			
			if(!("GET".equals(method) || "POST".equals(method) || "HEAD".equals(method))){
				sendError( HTTP_BADREQUEST, "Unsupported method "+method);
				return;				
			}
			
			if(!("HTTP/1.1".equals(protocol) || "HTTP/1.0".equals(protocol) )){
				sendError( HTTP_BADREQUEST, "Unsupported protocol "+protocol);
				return;				
			}

			//try if any extension will accept this session
			for(Extension ext : extensions){
				if(ext.accept(this))
					return; 
			}
			//not send error
			sendError(HTTP_NOTFOUND, "No extension can handle this url");
		
		}catch (IOException e){
			if(AsyncHttpd.log.isDebugEnabled())
				AsyncHttpd.log.debug("An exception during connection",e);
		}finally{
			//make sure connection is closed
			closeChannel(); 
		}
			
	}

	private void closeChannel() throws IOException {
		if(sc != null && sc.isOpen() ){
			//sc.close() is blocking, close using reflection hack in non blocking way
			try {
				closeMethod.invoke(sc);
			} catch (Throwable e) {
				if(AsyncHttpd.log.isWarnEnabled())
					AsyncHttpd.log.warn("Can not close channel in non blocking way",e);
				sc.close();
			}
		}
			
	}

	/** send error to channel */
	@pausable
	public void sendError( String status, String msg ) throws IOException{
		//TODO if map is null kilim waving fails
		sendHeaderResponse( status, MIME_PLAINTEXT);
		closeHeaderWithMsg(msg);
	}
	

	/** send string to channel */
	@pausable
	public void send(String msg) throws IOException {
		send(msg.getBytes());
	}

	/**
	 * Sends given response to the channel.
	 * @throws IOException 
	 */
	@pausable
	public void sendHeaderResponse( String status, String mime) throws IOException{
		Utils.neser(!headerSend,"Header already closed");		
		headerToSend.append(protocol);
		headerToSend.append(" ");
		headerToSend.append(status);
		headerToSend.append(Const.RN);
		
		if ( mime != null ){
			sendHeaderField("Content-Type",mime);
		}
	}

	/** close header so data can be send */
	@pausable
	public void closeHeader() throws IOException {
		closeHeaderWithMsg("");
	}
	
	@pausable
	public void closeHeaderWithMsg(CharSequence msg) throws IOException {
		Utils.neser(!headerSend,"Header already closed");
		headerSend = true;		
		headerToSend.append(Const.RN);
		headerToSend.append(msg);
		send(headerToSend.toString());
		headerToSend = null;
	}

	@pausable
	public void closeHeaderWithBuffer(ByteBuffer buffer) throws IOException {
		Utils.neser(!headerSend,"Header already closed");
		Utils.neser(buffer!=null, "Buffer is null");
		headerSend = true;		
		headerToSend.append(Const.RN);
		
		ByteBuffer[] bb = new ByteBuffer[2];
		bb[0] = ByteBuffer.wrap(headerToSend.toString().getBytes());
		headerToSend = null;
		bb[1] = buffer;
		
		send(bb);
	}

	/** send content of ByteBuffer to channel */
	@pausable
	public void send(ByteBuffer[] bb) throws IOException {
		Utils.neser(headerSend, "use closeHeader() before sending any data");
		while(bb[bb.length-1].remaining()!=0){
			assertReady();
			long wr = sc.write(bb);
			if(wr >1 )
				updateTimeout();
			else{
				yield();
			}
		}		

	}
	
	/** send content of ByteBuffer to channel */
	@pausable
	public void send(ByteBuffer buf) throws IOException {
		Utils.neser(headerSend, "use closeHeader() before sending any data");
		while(buf.remaining()!=0){
			assertReady();
			int wr = sc.write(buf);
			if(wr >1 )
				updateTimeout();
			else{
				yield();
			}
		}		
	}


	/** send optional header field */
	@pausable
	public void sendHeaderField(String name, String value) throws IOException {
		Utils.neser(!headerSend,"header already send");
		headerToSend.append(name);
		headerToSend.append(": ");
		headerToSend.append(value);
		headerToSend.append(Const.RN);
	}

	
	/** write string to socket */
	@pausable
	public void send(byte[] a) throws IOException {
		//get buffer
		ByteBuffer buf = ByteBuffer.wrap(a);
		send(buf);
	}
	
	

	/** read head send by client  */
	@pausable
	private String readRequest() throws IOException{
	    ByteBuffer buf = AsyncHttpd.bufferGenerator.get();
	    while(true){
	    	assertReady();
        	int read = sc.read(buf);
        	if(read>0){
        		
        		//check for double new line which indicates end of header
        		updateTimeout();
        		int pos = buf.position();
        		if(pos>3 &&
        				buf.get(pos-4)==Const.R && buf.get(pos-3)==Const.N &&
        				buf.get(pos-2)==Const.R && buf.get(pos-1)==Const.N){ 
        			//create copy of buffer, original buffer will be reused and cleaned, 
        			//changes in buffer will appear in returned string
        			buf.flip();
        			buf.limit(buf.limit()-4);
        			String ret = headDecoder.decode(buf).toString();
        			AsyncHttpd.bufferGenerator.reuse(buf);        	
        			return ret;
        		}
        	}        	
	    	yield();        	
	    }
	}

	/** call this when recivied data with IO */
	private void updateTimeout() {
		lastData = System.currentTimeMillis();
	}

	/** throws an exception if channel is not ready for IO */
	private void assertReady() throws IOException{
		if(!sc.isConnected())
			throw new IOException("Not connected");
		if(!sc.isOpen())
			throw new IOException("Not opened");
		if(sc.isBlocking())
			throw new IOException("Channel can not be blocking");
		
		if(lastData==0)
			lastData = System.currentTimeMillis();
		if(lastData+Const.TIMEOUT<System.currentTimeMillis())
			throw new IOException("Timeout exceeded");		
	}
	
	/** get entire request part in string */
	public String getRequest() {
		return request;
	}
	
	/** get fields from request */
	public Map<String,String> getRequestFields(){
		if(requestFields==null)
			parseRequestsFields();
		return requestFields;
	}
	
	/** get one field from request */
	public String getRequestField(String key) {
		return getRequestFields().get(key);
	}

	
	/** parse fields if needed */
	private void parseRequestsFields() {
		Utils.neser(requests!=null && requests.length>1,"request fields not parsed");
		//parse all requests lines
		requestFields = new LinkedHashMap<String,String>();
		for(int i=1;i<requests.length;i++){
			String s = requests[i];
			int off = s.indexOf(':');
			if(off==-1)
				continue;
			String key = s.substring(0,off);
			String val = s.substring(off+2);
			requestFields.put(key,val);
		}
		//make it unmodifiable
		requestFields = Collections.unmodifiableMap(requestFields);
	}

	/** get method of request */
	public String getMethod() {
		return method;
	}
	
	/** get requested URI */
	public String getUri() {
		return uri;
	}
	
	//TODO parsing parameters of URI
	
	/** get requested protocol */
	public String getProtocol() {
		return protocol;
	}


	public boolean isHeaderSend() {
		return headerSend;
	}

}
