package net.kotek.asynchttpd;

import java.io.IOException;
import java.nio.channels.ServerSocketChannel;
import java.nio.channels.SocketChannel;

/** this runnable takes care about listening for connections.
 *  it is not task, because it would consume all CPU without idle waiting
  */
public class ListenRunnable implements Runnable {

	private ServerSocketChannel ssc;

	public ListenRunnable(ServerSocketChannel ssc) {
		this.ssc = ssc;
	}

	public void run() {
		SocketChannel sc = null;
		while (true)
			try {
				//block until new connection arrives
				sc = ssc.accept();
				// create new task which handle it
				SessionTask ct = new SessionTask(sc);
				if(AsyncHttpd.log.isTraceEnabled())
					AsyncHttpd.log.trace("Connection accepted, starting RequestTask");
				ct.start();
			} catch (IOException e) {
				if(AsyncHttpd.log.isWarnEnabled())
					AsyncHttpd.log.warn("can not accept connection", e);
			}

	}

}
