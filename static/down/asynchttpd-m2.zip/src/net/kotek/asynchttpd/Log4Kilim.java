package net.kotek.asynchttpd;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayDeque;
import java.util.Queue;

/**
 * Simple Log4j style logger. Can log to file and std out. Does not block, uses
 * NIO and is pausable. Can implement commons-log Log interface. 
 * <p>
 * 
 * <p>
 * The six logging levels used by <code>Log</code> are (in order):
 * <ol>
 * <li>trace (the least serious)</li>
 * <li>debug</li>
 * <li>info</li>
 * <li>warn</li>
 * <li>error</li>
 * <li>fatal (the most serious)</li>
 * </ol>
 * The mapping of these log levels to the concepts used by the underlying
 * logging system is implementation dependent. The implementation should ensure,
 * though, that this ordering behaves as expected.
 * </p>
 * 
 * <p>
 * Performance is often a logging concern. By examining the appropriate
 * property, a component can avoid expensive operations (producing information
 * to be logged).
 * </p>
 * 
 * <p>
 * For example, <code><pre>
 *    if (log.isDebugEnabled()) {
 *        ... do something expensive ...
 *        log.debug(theResult);
 *    }
 * </pre></code>
 * </p>
 * 
 * <p>
 * Configuration of the underlying logging system will generally be done
 * external to the Logging APIs, through whatever mechanism is supported by that
 * system.
 * </p>
 * 
 * javadoc and interface is from jakarta commons-log
 */
public class Log4Kilim{

	public static final int TRACE = 1;
	public static final int DEBUG = 2;
	public static final int INFO = 3;
	public static final int WARN = 4;
	public static final int ERROR = 5;
	public static final int FATAL = 6;

	protected FileOutputStream fileOut;

	protected int fileLevel = 0;
	protected int consoleLevel = ERROR;

	protected static final int BUF_INIT_SIZE = 2048;

	protected Queue<byte[]> consoleQueue = new ArrayDeque<byte[]>();
	protected Queue<byte[]> fileQueue = new ArrayDeque<byte[]>();

	
	public Log4Kilim(File logFile) {
		try{
			fileOut = new FileOutputStream(logFile);
			//start writing thread
			writingThread.start();
		}catch(IOException e){
			throw new IllegalArgumentException("Error opening logFile", e);
		}
	}

	/**
	 * <p>
	 * Is debug logging currently enabled?
	 * </p>
	 * 
	 * <p>
	 * Call this method to prevent having to perform expensive operations (for
	 * example, <code>String</code> concatination) when the log level is more
	 * than debug.
	 * </p>
	 */
	public boolean isDebugEnabled() {
		return fileLevel <= DEBUG || consoleLevel <= DEBUG;
	}

	/**
	 * <p>
	 * Is error logging currently enabled?
	 * </p>
	 * 
	 * <p>
	 * Call this method to prevent having to perform expensive operations (for
	 * example, <code>String</code> concatination) when the log level is more
	 * than error.
	 * </p>
	 */
	public boolean isErrorEnabled() {
		return fileLevel <= ERROR || consoleLevel <= ERROR;
	}

	/**
	 * <p>
	 * Is fatal logging currently enabled?
	 * </p>
	 * 
	 * <p>
	 * Call this method to prevent having to perform expensive operations (for
	 * example, <code>String</code> concatination) when the log level is more
	 * than fatal.
	 * </p>
	 */
	public boolean isFatalEnabled() {
		return fileLevel <= FATAL || consoleLevel <= FATAL;
	}

	/**
	 * <p>
	 * Is info logging currently enabled?
	 * </p>
	 * 
	 * <p>
	 * Call this method to prevent having to perform expensive operations (for
	 * example, <code>String</code> concatination) when the log level is more
	 * than info.
	 * </p>
	 */
	public boolean isInfoEnabled() {
		return fileLevel <= INFO || consoleLevel <= INFO;
	}

	/**
	 * <p>
	 * Is trace logging currently enabled?
	 * </p>
	 * 
	 * <p>
	 * Call this method to prevent having to perform expensive operations (for
	 * example, <code>String</code> concatination) when the log level is more
	 * than trace.
	 * </p>
	 */
	public boolean isTraceEnabled() {
		return fileLevel <= TRACE || consoleLevel <= TRACE;
	}

	/**
	 * <p>
	 * Is warning logging currently enabled?
	 * </p>
	 * 
	 * <p>
	 * Call this method to prevent having to perform expensive operations (for
	 * example, <code>String</code> concatination) when the log level is more
	 * than warning.
	 * </p>
	 */
	public boolean isWarnEnabled() {
		return fileLevel <= WARN || consoleLevel <= WARN;
	}

	// -------------------------------------------------------- Logging Methods

	/**
	 * <p>
	 * Log a message with trace log level.
	 * </p>
	 * 
	 * @param message
	 *            log this message
	 */
	public void trace(String message) {
		log(TRACE, message, null);
	}

	/**
	 * <p>
	 * Log an error with trace log level.
	 * </p>
	 * 
	 * @param message
	 *            log this message
	 * @param t
	 *            log this cause
	 */
	public void trace(String message, Throwable t) {
		log(TRACE, message, t);
	}

	/**
	 * <p>
	 * Log a message with debug log level.
	 * </p>
	 * 
	 * @param message
	 *            log this message
	 */
	public void debug(String message) {
		log(DEBUG, message, null);
	}

	/**
	 * <p>
	 * Log an error with debug log level.
	 * </p>
	 * 
	 * @param message
	 *            log this message
	 * @param t
	 *            log this cause
	 */
	public void debug(String message, Throwable t) {
		log(DEBUG, message, t);
	}

	/**
	 * <p>
	 * Log a message with info log level.
	 * </p>
	 * 
	 * @param message
	 *            log this message
	 */
	public void info(String message) {
		log(INFO, message, null);
	}

	/**
	 * <p>
	 * Log an error with info log level.
	 * </p>
	 * 
	 * @param message
	 *            log this message
	 * @param t
	 *            log this cause
	 */
	public void info(String message, Throwable t) {
		log(INFO, message, null);
	}

	/**
	 * <p>
	 * Log a message with warn log level.
	 * </p>
	 * 
	 * @param message
	 *            log this message
	 */
	public void warn(String message) {
		log(WARN, message, null);
	}

	/**
	 * <p>
	 * Log an error with warn log level.
	 * </p>
	 * 
	 * @param message
	 *            log this message
	 * @param t
	 *            log this cause
	 */
	public void warn(String message, Throwable t) {
		log(WARN, message, t);
	}

	/**
	 * <p>
	 * Log a message with error log level.
	 * </p>
	 * 
	 * @param message
	 *            log this message
	 */
	public void error(String message) {
		log(ERROR, message, null);
	}

	/**
	 * <p>
	 * Log an error with error log level.
	 * </p>
	 * 
	 * @param message
	 *            log this message
	 * @param t
	 *            log this cause
	 */
	public void error(String message, Throwable t) {
		log(ERROR, message, t);
	}

	/**
	 * <p>
	 * Log a message with fatal log level.
	 * </p>
	 * 
	 * @param message
	 *            log this message
	 */
	public void fatal(String message) {
		log(FATAL, message, null);
	}

	/**
	 * <p>
	 * Log an error with fatal log level.
	 * </p>
	 * 
	 * @param message
	 *            log this message
	 * @param t
	 *            log this cause
	 */
	public void fatal(String message, Throwable t) {
		log(FATAL, message, t);
	}

	/**
	 * LOG message at given at level
	 * 
	 * @param level
	 *            at which log message
	 * @param message
	 *            message to log
	 * @param t
	 *            throwable associated with exception, can be null
	 */
	protected void log(int level, String message, Throwable t) {
		try {	
			if(!(fileLevel <= level || consoleLevel <= level))
				return;

			// Use a Char buffer from queue for better performance
			StringBuilder buf = new StringBuilder(BUF_INIT_SIZE);

			// Append date-time if so configured
			buf.append("|| ");
			buf.append(System.currentTimeMillis());
			buf.append(" ms | ");

			// Append a readable representation of the log level
			switch (level) {
			case TRACE:
				buf.append("TRACE");
				break;
			case DEBUG:
				buf.append("DEBUG");
				break;
			case INFO:
				buf.append("INFO");
				break;
			case WARN:
				buf.append("WARN");
				break;
			case ERROR:
				buf.append("ERROR ");
				break;
			case FATAL:
				buf.append("FATAL ");
				break;
			}
			buf.append(" | ");
			// thread name
			buf.append("[");
			buf.append(Thread.currentThread().getName());
			buf.append("] | ");

			// get file and line number
			try {
				StackTraceElement st = Thread.currentThread().getStackTrace()[3];
				buf.append(st.getFileName());
				buf.append(":");
				buf.append(st.getLineNumber());
				buf.append("#");
				buf.append(st.getMethodName());
			} catch (Throwable e) {
				buf.append("null");
			}
			buf.append(" | ");

			// append message
			buf.append(message);

			// Append stack trace if not null
			if (t != null) {
				buf.append("\n <");
				buf.append(t.toString());
				buf.append(">");

				java.io.StringWriter sw = new java.io.StringWriter(1024);
				java.io.PrintWriter pw = new java.io.PrintWriter(sw);
				t.printStackTrace(pw);
				pw.close();
				buf.append(sw.toString());
			}
			
			buf.append("\n");
			
			byte[] s  = buf.toString().getBytes();
			
			//schedule for writing to console
			if (consoleLevel <= level)
				consoleQueue.add(s);

			//schedule for writing into file
			if (fileLevel <= level)
				fileQueue.add(s);

		} catch (Throwable e) {
			// isolate underling app from any errors
			e.printStackTrace();
		}
	}
	
	public int getFileLevel() {
		return fileLevel;
	}
	
	public void setFileLevel(int fileLevel) {
		this.fileLevel = fileLevel;
	}
	
	public void setConsoleLevel(int consoleLevel) {
		this.consoleLevel = consoleLevel;
	}
	
	public int getConsoleLevel() {
		return consoleLevel;
	}
	
	protected Thread writingThread = new Thread("log-write") {
		{
			setDaemon(true);
		}

		@Override
		public void run() {
			while (true)
				try {
					// wait for more messages
					sleep(0, 100);

					// write messages from console queue
					byte[] s = consoleQueue.poll();
					while (s != null) {
						// write to console
						System.err.write(s);
						s = consoleQueue.poll();
					}

					// write messages from file queue
					s = fileQueue.poll();
					while (s != null) {
						// write to file
						fileOut.write(s);
						s = fileQueue.poll();
					}
					fileOut.flush();
				} catch (Throwable e) {
					e.printStackTrace();
				}
		}		
	};
	

}
