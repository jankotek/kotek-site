package net.kotek.asynchttpd;

/** various constants */
final class Const {
	
	static final byte R = (byte)'\r';
	static final byte N = (byte)'\n';
	
	static final String RN = "\r\n";
	static final String RN2 = "\r\n\r\n";
	
	static final long TIMEOUT = 10000; //TODO configurable timeout 

}
