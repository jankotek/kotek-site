package net.kotek.asynchttpd;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.nio.MappedByteBuffer;
import java.nio.channels.FileChannel;
import java.nio.channels.FileChannel.MapMode;
import java.util.Hashtable;
import java.util.StringTokenizer;

import kilim.pausable;

/** 
 * extension which handle files.
 * <p>
 * Based on  NanoHTTPD
 * <p>
 * TODO more optimalizations
 * 
 */
public class FileExtension implements Extension {

	File homeDir;
	boolean allowDirectoryListing = true;

	public FileExtension(File homeDir) {
		// make sure dir exist
		homeDir = homeDir.getAbsoluteFile();
		Utils.neser(homeDir != null && homeDir.isDirectory()
				&& homeDir.canRead(), "wrong root directory");
		this.homeDir = homeDir;
	}

	@pausable
	public boolean accept(SessionTask st) throws IOException {		
		serveFile(st);
		//TODO shouldnot accept non existing files?
		return true;
	}


	@pausable
	public void serveFile(SessionTask st) throws IOException {

		// Remove URL arguments
		String uri = st.getUri().trim().replace(File.separatorChar, '/');
		if (uri.indexOf('?') >= 0)
			uri = uri.substring(0, uri.indexOf('?'));

		// Prohibit getting out of current directory
		if (uri.startsWith("..") || uri.endsWith("..")
				|| uri.indexOf("../") >= 0){
			st.sendError(SessionTask.HTTP_FORBIDDEN, "FORBIDDEN: Won't serve ../ for security reasons.");
			return;
		}

		File f = new File(homeDir, uri);
		if (!f.exists()){
			st.sendError(SessionTask.HTTP_NOTFOUND, "Error 404, file not found.");
			return;
		}

		// List the directory, if necessary
		if (f.isDirectory()) {
			// Browsers get confused without '/' after the
			// directory, send a redirect.
			if (!uri.endsWith("/")) {
				uri += "/";
				st.sendHeaderResponse(SessionTask.HTTP_REDIRECT, SessionTask.MIME_HTML);
				st.sendHeaderField("Location", uri);
				st.closeHeader();
				st.send(
						"<html><body>Redirected: <a href=\"" + uri + "\">"
								+ uri + "</a></body></html>");
				
				return;
			}

			// First try index.html and index.htm
			if (new File(f, "index.html").exists())
				f = new File(homeDir, uri + "/index.html");
			else if (new File(f, "index.htm").exists())
				f = new File(homeDir, uri + "/index.htm");

			// No index file, list the directory
			else if (allowDirectoryListing) {
				sendDirectoryList(st, uri, f);
				return;
			} else {
				st.sendError(SessionTask.HTTP_FORBIDDEN, "Directory listening forbidden.");
				return;
			}
		}

		try {
			//TODO replace with more complete list, maybe binary parsing?
			// Get MIME type from file name extension, if possible
			String mime = null;
			int dot = f.getCanonicalPath().lastIndexOf('.');
			if (dot >= 0)
				mime = (String) theMimeTypes.get(f.getCanonicalPath()
						.substring(dot + 1).toLowerCase());
			if (mime == null)
				mime = SessionTask.MIME_DEFAULT_BINARY;

			// Support (simple) skipping:
			long startFrom = 0;
			String range = st.getRequestField("Range");
			if (range != null) {
				if (range.startsWith("bytes=")) {
					range = range.substring("bytes=".length());
					int minus = range.indexOf('-');
					if (minus > 0)
						range = range.substring(0, minus);
					try {
						startFrom = Long.parseLong(range);
					} catch (NumberFormatException nfe) {
					}
				}
			}

			// open channel before header is open, so exception is thrown if before headers
			FileInputStream fis = new FileInputStream(f);
			FileChannel fc = fis.getChannel();
			MappedByteBuffer mbb = fc.map(MapMode.READ_ONLY, startFrom, f.length());
			st.sendHeaderResponse(SessionTask.HTTP_OK, mime);
			st.sendHeaderField("Content-length", "" + (f.length() - startFrom));
			st.sendHeaderField("Content-range", "" + startFrom + "-"
					+ (f.length() - 1) + "/" + f.length());
			st.closeHeaderWithBuffer(mbb);			
			
			return;
		} catch (IOException ioe) {
			if(!st.isHeaderSend())
				st.sendError(SessionTask.HTTP_FORBIDDEN, "FORBIDDEN: Reading file failed.");
			
			if(AsyncHttpd.log.isDebugEnabled())
				AsyncHttpd.log.debug("Error when sending file",ioe);
		
			return;
		}
	}

	/** generate file list */
	@pausable
	private void sendDirectoryList(SessionTask st, String uri, File f)
			throws IOException {
		String[] files = f.list();
		if(files==null){
			st.sendError(SessionTask.HTTP_FORBIDDEN, "FORBIDDEN: Can not read directory content.");
			return;

		}
		StringBuilder msg = new StringBuilder(1024);
		msg.append("<html><body><h1>Directory ");
		msg.append(uri);
		msg.append("</h1><br/>");

		if (uri.length() > 1) {
			String u = uri.substring(0, uri.length() - 1);
			int slash = u.lastIndexOf('/');
			if (slash >= 0 && slash < u.length()){
				msg.append("<b><a href=\"");
				msg.append(uri.substring(0, slash + 1));
				msg.append("\">..</a></b><br/>");
			}
		}
		
		for (int i = 0; i < files.length; ++i) {
			File curFile = new File(f, files[i]);
			boolean dir = curFile.isDirectory();
			if (dir) {
				msg.append("<b>");
				files[i] += "/";
			}

			msg.append("<a href=\"");
			msg.append(encodeUri(uri + files[i]));
			msg.append("\">");
			msg.append(files[i]);
			msg.append("</a>");

			// Show file size
			if (curFile.isFile()) {
				long len = curFile.length();
				msg.append(" &nbsp;<font size=2>(");
				msg.append(getFileSize(len));
				msg.append(")</font>");
			}
			msg.append("<br/>");
			if (dir)
				msg.append("</b>");
		}
		st.sendHeaderResponse(SessionTask.HTTP_OK, SessionTask.MIME_HTML);
		st.closeHeaderWithMsg(msg);
		return;
	}

	/**
	 * URL-encodes everything between "/"-characters.
	 * Encodes spaces as '%20' instead of '+'.
	 */
	private String encodeUri( String uri )
	{
		String newUri = "";
		StringTokenizer st = new StringTokenizer( uri, "/ ", true );
		while ( st.hasMoreTokens())
		{
			String tok = st.nextToken();
			if ( tok.equals( "/" ))
				newUri += "/";
			else if ( tok.equals( " " ))
				newUri += "%20";
			else
			{
				//newUri += URLEncoder.encode( tok,"UTF-8");
				// For Java 1.4 you'll want to use this instead:
				try { 
					newUri += URLEncoder.encode( tok, "UTF-8" ); 
				} catch ( UnsupportedEncodingException uee ){};
			}
		}
		newUri = newUri.replace(' ','+');
		return newUri;
	}

	
	/** @return file size in humen readable format */
	private String getFileSize(long len){
		String msg = "";
		if (len < 1024)
			msg += len + " bytes";
		else if (len < 1024 * 1024)
			msg += len / 1024 + "."
					+ (len % 1024 / 10 % 100)
					+ " KB";
		else
			msg += len / (1024 * 1024) + "."
					+ len % (1024 * 1024) / 10
					% 100 + " MB";
		return msg;
	}
	
	/**
	 * Hashtable mapping (String)FILENAME_EXTENSION -> (String)MIME_TYPE
	 */
	private static Hashtable theMimeTypes = new Hashtable();
	static
	{
		StringTokenizer st = new StringTokenizer(
			"htm		text/html "+
			"html		text/html "+
			"txt		text/plain "+
			"asc		text/plain "+
			"gif		image/gif "+
			"jpg		image/jpeg "+
			"jpeg		image/jpeg "+
			"png		image/png "+
			"mp3		audio/mpeg "+
			"m3u		audio/mpeg-url " +
			"pdf		application/pdf "+
			"doc		application/msword "+
			"ogg		application/x-ogg "+
			"zip		application/octet-stream "+
			"exe		application/octet-stream "+
			"class		application/octet-stream " );
		while ( st.hasMoreTokens())
			theMimeTypes.put( st.nextToken(), st.nextToken());
	}

}
