package net.kotek.asynchttpd.test;

import java.net.*;
import java.io.*;

//testing sample from 
// http://www.mcwalter.org/technology/java/httpd/tiny/index.html
//h.java (c)1999-2004 W.Finlay McWalter. Licence: GPLv2.0
//v1: me: initial version
//v2: me: squished down by four lines
//v3: Jonathan Headland: removed a couple of redundant checks
//v4: Engelbert Gruber: changed input stream to a BufferedReader
//v5: me: small speedup/codesize-reduction in writeBytes length code
//v6: Luke: replaced StringTokenizer with split, saving two lines
//v7: Luke: made FileInputStream anon   me: GET->GE
//----------------------------------------------------------------- 
public class MicroHTTPD extends Thread {
	Socket c;

	public MicroHTTPD(Socket s) {
		c = s;
		start();
	}

	public static void main(String[] a) {
		try {
			ServerSocket s = new ServerSocket(8888);
			for (;;) {
				new MicroHTTPD(s.accept());
			}
		} catch (Exception e) {
		}
	}

	public void run() {
		try {
			BufferedReader i = new BufferedReader(new InputStreamReader(c
					.getInputStream()));
			DataOutputStream o = new DataOutputStream(c.getOutputStream());
			try {
				String s, p;
				while ((s = i.readLine()).length() > 0) {
					if (s.startsWith("GE")) {
						p = (s.split(" "))[1];
						p = ("." + (p.endsWith("/") ? p + "index.html" : p))
								.replace('/', File.separatorChar);
						int l = (int) new File(p).length();
						byte[] b = new byte[l];
						new FileInputStream(p).read(b);
						o.writeBytes("HTTP/1.0 200 OK\nContent-Length:" + l
								+ "\n\n");
						o.write(b, 0, l);
					}
				}
			} catch (Exception e) {
				o.writeBytes("HTTP/1.0 404 ERROR\n\n");
			}
			o.close();
		} catch (Exception e) {
		}
	}
}