package net.kotek.asynchttpd;

import java.io.File;
import java.io.IOException;
import java.net.InetSocketAddress;
import java.nio.channels.ServerSocketChannel;
import java.util.LinkedList;
import java.util.List;
import java.util.Properties;

import kilim.Scheduler;

/** class which wraps http daemon */
public class AsyncHttpd {
	
	/** logger for entire server */
	static Log4Kilim log;
	
	/** factory which reuses buffers */
	static BufferGenerator bufferGenerator;

	public static List<Extension> extensions;

	/** configuration properties of this daemon */
	private Properties properties;
	
	public AsyncHttpd(){
	}

	/** set configuration properties (IE from CLI) */
	public void setProperties(Properties properties) {
		this.properties = properties;
	}
	
	/** starts server 
	 * @throws IOException if web server can not bind itself to port 
	 * */
	public void start() throws IOException{
		Utils.neser(properties!=null,"properties not set");
		
		//initialize buffer generator
		int bufferSize = Cli.getInt(properties, Cli.BUFFER_SIZE, Cli.BUFFER_SIZE_DEF);
		bufferGenerator = new BufferGenerator(bufferSize);
		
		//create extensions
		extensions = new LinkedList<Extension>();
		String homeDir = properties.getProperty(Cli.HOME_DIR);
		Utils.neser(homeDir!=null, Cli.HOME_DIR +" option is not set");
		FileExtension fe = new FileExtension(new File(homeDir));
		extensions.add(fe);
				
        // Create a socket channel 
		int port = Cli.getInt(properties, Cli.PORT, Cli.PORT_DEF);
        ServerSocketChannel ssc = ServerSocketChannel.open();
        ssc.socket().bind(new InetSocketAddress(port));        
        
        //create task which handles new connections
        if(!properties.containsKey(Cli.ASYNC_LISTEN)){
        	//create thread which waits for new connections in blocking mode
        	ListenRunnable lt = new ListenRunnable(ssc);
        	new Thread(lt,"listen-thread").start();
        }else{
        	//create task which waits in non blocking mode, but consume lot of CPU
        	ListenTask lt= new ListenTask(ssc);
        	lt.start();
        }
        	
        System.out.println("AsyncHttpd is listening at "+port + " with home directory "+homeDir);		
	}	
	
	public static void main(String[] args) {
		try{				
			Properties prop = Cli.args2prop(args);

			//write help if needed
			if(prop.size() == 0 || prop.containsKey(Cli.HELP)){
				String hf = Utils.readResourceToString("help.txt");
				System.out.println(hf);
				return;
			}

			
			//set number of working threads for tasks
			int numThreads = Cli.getInt(prop, Cli.THREADS, Cli.THREADS_DEF);
			Scheduler.setDefaultScheduler(new Scheduler(numThreads));
			//scheduler is set, now start logger
			String logFile = prop.getProperty(Cli.LOG_FILE, Cli.LOG_FILE_DEFAULT);
			log = new Log4Kilim(new File(logFile));
			log.setConsoleLevel(Cli.getInt(prop, Cli.LOG_LEVEL_CONSOLE, Log4Kilim.ERROR));
			log.setFileLevel(Cli.getInt(prop, Cli.LOG_LEVEL_FILE, Log4Kilim.DEBUG));
			
			//now start webserver
			AsyncHttpd httpd = new AsyncHttpd();
			httpd.setProperties(prop);
			httpd.start();	        
		}catch (Throwable e){
			if(log!=null)
				log.fatal("An error in main method", e);
			System.err.println("===========");
			System.err.println("Fatal error, can not start httpd");
			e.printStackTrace();
			System.exit(-1);
		}
	}
	
}
