package net.kotek.asynchttpd;

import java.util.Arrays;
import java.util.List;
import java.util.Properties;

/** everything related to command line arguments */
class Cli {
	
	static final int PORT_DEF = 8888;
	static final String PORT = "port";
	
	static final int THREADS_DEF = 1;
	static final String THREADS = "threads";
	
	static final String BUFFER_SIZE = "buffer-size";
	static final int BUFFER_SIZE_DEF = 1024 * 4;
	static final String LOG_FILE = "log-file";
	static final String LOG_FILE_DEFAULT = "asynchttpd.log";
	
	static final String ASYNC_LISTEN = "async-listen";
		
	static final String LOG_LEVEL_CONSOLE = "log-level-console";
	static final String LOG_LEVEL_FILE = "log-level-file";
	static final String HOME_DIR ="home-dir";
	static final String HELP ="HELP";
	
	/** legal command line options, enything else couse error */
	static final String[] CLI_OPT = {PORT, THREADS, BUFFER_SIZE, LOG_FILE, 
		ASYNC_LISTEN, LOG_FILE, LOG_LEVEL_CONSOLE, LOG_LEVEL_FILE, HOME_DIR};
	

	/** convert command line arguments to properties */
	static Properties args2prop(String[] args){
		List<String> cliOpt = Arrays.asList(CLI_OPT);
		Properties prop = new Properties();
		for(String arg:args){
			arg = arg.replaceAll("^-+", "");
			int i = arg.indexOf("=");
			String a1 = "";
			String a2 = "true";
			if(i == -1)
				a1 = arg;
			else{
				a1 = arg.substring(0, i);
				a2 = arg.substring(i+1,arg.length());
			}
			Utils.neser(cliOpt.contains(a1),"Illegal argument: "+a1);			
			prop.put(a1, a2);			
		}
		return prop;
	}
	
	/** get int value from CLI properties */
	static int getInt(Properties properties, String key, int defaultValue){
		String val = properties.getProperty(key, ""+defaultValue);
		return Integer.valueOf(val);
	}

}
