package net.kotek.asynchttpd;

import java.io.IOException;

import kilim.pausable;

/** interface for extending server */
public interface Extension {
	
	/**  
	 * This method is invoked when connection and request are received.
	 * SHOULD be pausable or block for very long time. 
	 * <p>
	 * Must block until all data are send, connection is closed immediately after 
	 * method accept.
	 * <p>
	 * If extension can not handle this session, return false and next Extension in row
	 * will be used.
	 * <p>
	 * @param st session which contains connection and metadata
	 * @return boolean true if this extension handled this session
	 * @throws IOException if connection is broken, dont throw for operations related for Extension (FILE IO)
	 */
	@pausable
	boolean accept(SessionTask st) throws IOException;
	
}
