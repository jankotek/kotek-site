package net.kotek.asynchttpd;

import java.io.IOException;
import java.nio.channels.ServerSocketChannel;
import java.nio.channels.SocketChannel;

import kilim.Task;
import kilim.pausable;

/** this task listens for connections and handle it. 
 *  unlike ListenRunnable is non blocking and consumes all CPU in infinitive loop
  */
public class ListenTask extends Task {

	private ServerSocketChannel ssc;

	public ListenTask(ServerSocketChannel ssc) throws IOException {
		this.ssc = ssc;
		this.ssc.configureBlocking(false);
	}

	@pausable
	public void execute() {
		SocketChannel sc = null;
		while (true)
			try {
				//block until new connection arrives
				sc = ssc.accept();
				if(sc == null){
					yield(); //no new connection, give chance to other fibers
				}else{
					// create new task which handle it
					SessionTask ct = new SessionTask(sc);
					if(AsyncHttpd.log.isTraceEnabled())
						AsyncHttpd.log.trace("Connection accepted, starting RequestTask");
					ct.start();
				}
			} catch (IOException e) {
				if(AsyncHttpd.log.isWarnEnabled())
					AsyncHttpd.log.warn("can not accept connection", e);
			}

	}

}
