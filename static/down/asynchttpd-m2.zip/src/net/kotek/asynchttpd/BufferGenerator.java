package net.kotek.asynchttpd;

import java.nio.ByteBuffer;
import java.util.ArrayDeque;
import java.util.Queue;

/** factory which create and reuse of byte buffers */ 
public class BufferGenerator{

	private static final int PREALOCATE = 1024;

	private static final int MAX_SIZE = PREALOCATE * 10;

	private static final int MINIMAL_BUF_SIZE = 2048;

	private Queue<ByteBuffer> buffers = new ArrayDeque<ByteBuffer>(PREALOCATE);
	
	private int bufferSize;	

	public BufferGenerator(int bufferSize) {
		Utils.neser(bufferSize>=MINIMAL_BUF_SIZE, "Minimal buffer size is "+MINIMAL_BUF_SIZE);
		this.bufferSize = bufferSize;
		//Preallocate a few buffers
		for(int i=0;i<PREALOCATE;i++);
			reuse(createBuffer());
		if(AsyncHttpd.log.isDebugEnabled())
			AsyncHttpd.log.debug("BufferGenerator initialized with MAX_SIZE: "+MAX_SIZE+", BUFFER_SIZE:"+bufferSize);
	}

	/** get new ByteBuffer from factory */
	public ByteBuffer get(){
		ByteBuffer bb = buffers.poll();
		if(bb==null)
			//not in queue, create new one
			bb = createBuffer();
		return bb;
	}
		
	/** put byte buffer back to factory for reuse */
	public void reuse(ByteBuffer bb){
		if(buffers.size()>=MAX_SIZE) //dont reuse if maximal size is exceeded, can cause memory leak;
			return; 
		bb.clear();
		buffers.add(bb);
	}
	
	private ByteBuffer createBuffer(){
		return ByteBuffer.allocateDirect(bufferSize);
	}
	
}
