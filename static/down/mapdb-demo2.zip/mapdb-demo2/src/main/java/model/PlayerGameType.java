package model;

public enum PlayerGameType {
  SINGLE_PLAYER,
  ONE_ON_ONE,
  TOURNAMENT
}
