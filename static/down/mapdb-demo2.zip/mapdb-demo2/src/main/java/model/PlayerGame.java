package model;

import java.util.Date;

public class PlayerGame {
  
//  @Id
//  @GeneratedValue
  private long playerGameId;
  
//  @ManyToOne
  private Player player;
  
  private PlayerGameType type;
  private PlayerGameStatus status;
  private Date gameStart;
  private Date gameEnd;
  private long playerScore;

  // Derive that this is a @ManyToOne relationship  
  private Game game;
  
}