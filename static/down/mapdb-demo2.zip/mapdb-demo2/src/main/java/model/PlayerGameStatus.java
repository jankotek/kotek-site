package model;

public enum PlayerGameStatus {
  SCHEDULED,
  INPLAY,
  COMPLETE
}