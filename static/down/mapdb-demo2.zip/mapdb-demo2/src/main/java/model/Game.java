package model;

import java.io.Serializable;

public class Game implements Comparable<Game>,Serializable {

  protected final String playerName;


    public Game(String playerName) {
        this.playerName = playerName;
    }

    @Override
    public int compareTo(Game o) {
        return playerName.compareTo(o.playerName);
    }

    @Override
    public String toString() {
        return "Game{"+playerName+"}";
    }


    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        Game game = (Game) o;

        if (playerName != null ? !playerName.equals(game.playerName) : game.playerName != null) return false;

        return true;
    }

    @Override
    public int hashCode() {
        return playerName != null ? playerName.hashCode() : 0;
    }
}
