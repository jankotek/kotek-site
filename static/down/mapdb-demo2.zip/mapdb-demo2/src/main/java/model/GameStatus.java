package model;


public enum GameStatus {
  TRIAL,
  ACTIVE,
  DISCONTINUED
}