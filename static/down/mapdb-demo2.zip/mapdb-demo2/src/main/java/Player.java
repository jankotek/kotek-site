
// Create a database all from maps
// A subset of JPA but simpler and easier
// Schema-less creation, yet supports relational sharding

// AngryShards example.

// Possibly use the last 2 elements of the package or the domain and schema, 
// or just use the default domain, schema. You can also nest classes if you want
// into one or more model classes. And you can use annotations for the domain, schema.
/*
package com.dbshards.example.model.angryshardsdomain.angryshards;


/////////////////////////////////////////////////////////
// Example Prototype 1: Entity classes with annotations
/////////////////////////////////////////////////////////
@Entity
public class Player {

  @Id
  @GeneratedValue
  private long playerId;
  
  private String playerEmail;
  private String screenName;
  private int playerBalance;
  
  ...setters, getters
  
}

public enum PlayerGameType {
  SINGLE_PLAYER,
  ONE_ON_ONE,
  TOURNAMENT
}

public enum GameStatus {
  TRIAL,
  ACTIVE,
  DISCONTINUED
}

public enum PlayerGameStatus {
  SCHEDULED,
  INPLAY,
  COMPLETE
}

@Entity
public class Game {
  @Id
  @GeneratedValue
  private long gameId;
  
  private String name;
  private String description;
  private GameStatus status;
}

@Entity
public class PlayerGame {
  
  @Id
  @GeneratedValue
  private long playerGameId;
  
  @ManyToOne
  private Player player;
  
  private PlayerGameType type;
  private PlayerGameStatus status;
  private Date gameStart;
  private Date gameEnd;
  private long playerScore;

  // Derive that this is a @ManyToOne relationship  
  private Game game;
  
}

// Use DB to create maps. 
// Alternatively maybe we can allow creation of regular maps, and override in byte code
// with default settings configured with SCL.
Map<Long,Game> gameMap = DB...

Map<Long,Player> playerMap = DB...

Map<Long,PlayerGame> playerGameMap = DB...

// Create a single game.
Game game = new Game();
game.setName("AngryShards");
game.setDescription("The rise of the Sharder");
game.setStatus(GameStatus.TRIAL);

gameMap.put(game);

Player player = new Player();
player.setGame(game);
player.setEmail("joe@somewhere.com");
player.setScreenName("dbslayer");

playerMap.put(0,player);

// Now player has a generated ID

PlayerGame playerGame = new PlayerGame();

playerGame.setPlayer = player;
playerGame.set...

playerGameMap.put(0, playerGame);

// Get a list of PlayerGame objects for a Player.
// For query support WHERE clause syntax, or JP QL.
List<PlayerGame> resultPlayerGameList = DBQuery.query( 
  "SELECT pg FROM PlayerGame pg WHERE pg.player.id = ?1 AND status = ?2 ORDER BY game_end")
    .setParameter(1, player.getId())
    .setParameter(PlayerGameStatus.COMPLETE);

// Get a list of PlayerGame scores for a Player.
List<Long> resultPlayerGameScoreList = DBQuery.query( 
  "SELECT pg.playerScore FROM PlayerGame pg WHERE pg.player.id = ?1 AND status = ?2 ORDER BY game_end")
    .setParameter(1, player.getId())
    .setParameter(PlayerGameStatus.COMPLETE);

// Get a single object.
PlayerGame playerGame = playerGameMap.get(playerGame.getPlayerGameId);


/////////////////////////////////////////////////////////
// Example Prototype 2: Annotations at the Map level
/////////////////////////////////////////////////////////
import org.mapdb.annotations.*;

public class Player {

  private long playerId;
  
  private String playerEmail;
  private String screenName;
  private int playerBalance;
  
  ...setters, getters
  
}

public enum PlayerGameType {
  SINGLE_PLAYER,
  ONE_ON_ONE,
  TOURNAMENT
}

public enum GameStatus {
  TRIAL,
  ACTIVE,
  DISCONTINUED
}

public enum PlayerGameStatus {
  SCHEDULED,
  INPLAY,
  COMPLETE
}

public class Game {

  private long gameId;
  
  private String name;
  private String description;
  private GameStatus status;
}

public class PlayerGame {
  
  private long playerGameId;
  
  private Player player;
  
  private PlayerGameType type;
  private PlayerGameStatus status;
  private Date gameStart;
  private Date gameEnd;
  private long playerScore;

  // Derive that this is a @ManyToOne relationship  
  private Game game;
  
}

// Use DB to create maps. 
@Entity
@PrimaryKey(Game.gameId)
@GenerateId("game")
Map<Long,Game> gameMap = db.getMap...

Map<Long,Game> gameMap = db.getMap("game").primaryKey("gameId").autoincrement().cache();

@Entity
@PrimaryKey(Player.playerId)
@GenerateId("player")
Map<Long,Player> playerMap = DBMaker...

@Entity
@PrimaryKey(PlayerGame.playerGameId)
@GenerateId("playerGame")
@References(Player)
Map<Long,PlayerGame> playerGameMap = DbMaker...

Map<Long,PlayerGame> playerGameMap = db.getMap("playerGame").primaryKey("playerGameId")
  .autoincrement().foreignKey(Player, "player");

// Create a single game.
Game game = new Game();
game.setName("AngryShards");
game.setDescription("The rise of the Sharder");
game.setStatus(GameStatus.TRIAL);

gameMap.put(game);

Player player = new Player();
player.setGame(game);
player.setEmail("joe@somewhere.com");
player.setScreenName("dbslayer");

playerMap.put(0,player);
// Now player has a generated ID

PlayerGame playerGame = new PlayerGame();

playerGame.setPlayer = player;
playerGame.set...

playerGameMap.put(0, playerGame);

// Get a list of PlayerGame objects for a Player with a specific status.
// For query support WHERE clause syntax, or JP QL.
List<PlayerGame> resultPlayerGameList = db.query(playerGameMap,
  " ")
    .setParameter(1, player.getId())
    .setParameter(PlayerGameStatus.COMPLETE);

// Get a list of PlayerGame scores for a Player.
List<Long> resultPlayerGameScoreList = db.query(playerGameMap,
  "SELECT pg.playerScore FROM PlayerGame pg WHERE pg.player.id = ?1 AND status = ?2 ORDER BY game_end")
    .setParameter(1, player.getId())
    .setParameter(PlayerGameStatus.COMPLETE);

// Get a single object.
PlayerGame playerGame = playerGameMap.get(playerGame.getPlayerGameId);


/////////////////////////////////////////////////////////
// Example Prototype 3: Use MapDB Builder API
/////////////////////////////////////////////////////////
import org.mapdb.annotations.*;

public class Player {

  private long playerId;
  
  private String playerEmail;
  private String screenName;
  private int playerBalance;
  
  ...setters, getters
  
}

public enum PlayerGameType {
  SINGLE_PLAYER,
  ONE_ON_ONE,
  TOURNAMENT
}

public enum GameStatus {
  TRIAL,
  ACTIVE,
  DISCONTINUED
}

public enum PlayerGameStatus {
  SCHEDULED,
  INPLAY,
  COMPLETE
}

public class Game {

  private long gameId;
  
  private String name;
  private String description;
  private GameStatus status;
}

public class PlayerGame {
  
  private long playerGameId;
  
  private Player player;
  
  private PlayerGameType type;
  private PlayerGameStatus status;
  private Date gameStart;
  private Date gameEnd;
  private long playerScore;

  // Derive that this is a @ManyToOne relationship  
  private Game game;
  
}

// Use DB to create maps. 
Map<Long,Game> gameMap = db.getMap("game").primaryKey("gameId").autoincrement().cache();

Map<Long,Player> playerMap = db.getMap("player").primaryKey("playerId").autoincrement().cache();

Map<Long,PlayerGame> playerGameMap = db.getMap("playerGame").primaryKey("playerGameId")
  .autoincrement().foreignKey(Player, "player");

// Create a single game.
Game game = new Game();
game.setName("AngryShards");
game.setDescription("The rise of the Sharder");
game.setStatus(GameStatus.TRIAL);

gameMap.put(game);

Player player = new Player();
player.setGame(game);
player.setEmail("joe@somewhere.com");
player.setScreenName("dbslayer");

playerMap.put(0,player);
// Now player has a generated ID

PlayerGame playerGame = new PlayerGame();

playerGame.setPlayer = player;
playerGame.set...

playerGameMap.put(0, playerGame);

// Get a list of PlayerGame objects for a Player with a specific status.
// For query support WHERE clause syntax, or JP QL.
List<PlayerGame> resultPlayerGameList = db.query(playerGameMap,
  " ")
    .setParameter(1, player.getId())
    .setParameter(PlayerGameStatus.COMPLETE);

// Get a list of PlayerGame scores for a Player.
List<Long> resultPlayerGameScoreList = db.query(playerGameMap,
  "SELECT pg.playerScore FROM PlayerGame pg WHERE pg.player.id = ?1 AND status = ?2 ORDER BY game_end")
    .setParameter(1, player.getId())
    .setParameter(PlayerGameStatus.COMPLETE);

// Get a single object.
PlayerGame playerGame = playerGameMap.get(playerGame.getPlayerGameId);


*/