package slides;

import org.mapdb.DB;
import org.mapdb.DBMaker;
import util.Large_Data_Create;

import java.io.File;
import java.util.Map;
import java.util.Random;
import java.util.UUID;

/**
 * Demonstrates large data querying
 *
 *   > Imported 2,000,000,000 entries in 968 s
 *   > Import rate 2,065,513 entries per second
 *
 */
public class B_Large_Data {

    static final File STORE = Large_Data_Create.STORE;

    public static void main(String[] args) {
        DB db = DBMaker
                .newFileDB(STORE)
                .mmapFileEnable()
                .transactionDisable()
                .cacheDisable()
                .make();

        Map<Long, UUID> map = db.getTreeMap("idToUUID");

        if(map.isEmpty()){
            throw new Error("Import data first");
        }

        final Random rand = new Random();

        final long interval = 30_000;
        long t = System.currentTimeMillis();

        long counter=0;
        while(t+interval>System.currentTimeMillis()){
            Long key = (long) (rand.nextLong() % 1e9);
            UUID value = map.get(key);
            counter++;
        }

        System.out.println();
        System.out.printf("Lookups %,d in %d seconds\n",counter,interval/1000);
        System.out.printf("Lookups  %,d per second\n", 1000*counter/interval);
        System.out.printf("Total size of map is %,d entries \n", map.size());


        t = System.currentTimeMillis();
        counter=0;
        while(t+interval>System.currentTimeMillis()){
            Long key = (long) (rand.nextLong() % 1e9);
            UUID value = new UUID(rand.nextLong(), rand.nextLong());
            map.put(key,value);
            counter++;
        }

        System.out.println();
        System.out.printf("Updates %,d in %d seconds\n",counter,interval/1000);
        System.out.printf("Updates  %,d per second\n", 1000*counter/interval);
        System.out.printf("Total size of map is %,d entries \n", map.size());


        db.close();
    }

}
