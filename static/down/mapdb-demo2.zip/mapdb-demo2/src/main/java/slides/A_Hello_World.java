package slides;

import model.Player;
import org.mapdb.DB;
import org.mapdb.DBMaker;

import java.io.File;
import java.util.concurrent.ConcurrentNavigableMap;

/**
 * Instantiate MapDB collection
 */
public class A_Hello_World {

    public static void main(String[] args) {

        //Configure and open database using builder pattern.
        //All options are available with code auto-completion.
        File dbFile = new File("/tmp/mapdb_hello_world");

        DB db = DBMaker.newFileDB(dbFile)
                .encryptionEnable("password")
                .make();

        //open an collection
        ConcurrentNavigableMap<Integer, Player> map =
                db.getTreeMap("collectionName");

        map.put(1, new Player("john@example.com", "John Doe"));
        map.put(2, new Player("brian@example.com", "Brian Ryan"));
        //map.keySet() now contains [1,2]

        db.commit();  //persist changes into disk

        map.put(3, new Player("neil@example.com", "Neil Smith"));
        //map.keySet() is now [1,2,3]

        db.rollback(); //revert recent changes
        //map.keySet() is now [1,2]

        db.close();

    }
}
