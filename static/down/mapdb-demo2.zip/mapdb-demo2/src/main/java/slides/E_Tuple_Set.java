package slides;

import org.mapdb.BTreeKeySerializer;
import org.mapdb.DB;
import org.mapdb.DBMaker;
import org.mapdb.Fun;

import java.util.Map;
import java.util.concurrent.ConcurrentNavigableMap;
import static org.mapdb.Fun.*;

/**
 * Demonstrates composite keys.
 */
public class E_Tuple_Set {

    /**
     * In this example we demonstrate spatial queries on a Map
     * filled with Player > Income pairs.
     * <p/>
     * Address is represented as three-value-tuple.
     * First value is State, second is Team and third value is Player
     * <p/>
     * Java Generics are buggy, so we left out some type annotations for simplicity.
     * I would recommend more civilized language with type inference such as Kotlin or Scala.
     */
    public static void main(String[] args) {

        //initial values
        DB db = DBMaker.newMemoryDB().make();
        // initialize map
        // note that it uses BTreeKeySerializer.TUPLE3 to minimise disk space used by Map
        ConcurrentNavigableMap<Fun.Tuple3, Integer> map =
                db
                        .createTreeMap("map")
                        .keySerializer(BTreeKeySerializer.TUPLE3)
                        .make();


        //fill with values, use simple permutation so we dont have to include large test data.

        map.put(new Tuple3("Colorado","Avalanche","Brian Elliott"),1_000_000);
        map.put(new Tuple3("Colorado","Avalanche","Tyler Weiman"),1_200_000);
        map.put(new Tuple3("Colorado","Avalanche","Roy Patrick"),1_300_000);
        map.put(new Tuple3("California","Kings","Dafoe Byron"),1_300_000);
        map.put(new Tuple3("New York","Islanders","Danny Lorenz"),1_300_000);
        map.put(new Tuple3("New York","Islanders","George Maneluk"),1_300_000);
        map.put(new Tuple3("New York","Ranges","Gene Carr"),1_300_000);



        System.out.println("There are "+map.size()+ " players in total");  //NOTE: map.size() traverses entire map


        //Lets get all players in New York
        //Values are sorted so we can query sub-range (values between lower and upper bound)
        Map<Fun.Tuple3, Integer>
                playersInNewYork = map.subMap(
                Fun.t3("New York", null, null), //null is 'negative infinity'; everything else is larger than null
                Fun.t3("New York", Fun.HI, Fun.HI) // 'HI' is 'positive infinity'; everything else is smaller then 'HI'
        );

        System.out.println("There are "+playersInNewYork.size()+ " players in New York");

        //lets make sum of all salaries on New York
        int total = 0;
        for(Integer salary:playersInNewYork.values()){
            total+=salary;
        }
        System.out.println("Salary sum for New York is: "+total);


        //other example, lets remove Colorado Avalanche from DB
        map.subMap(
                Fun.t3("Colorado", "Avalanche", null),
                Fun.t3("Colorado", "Avalanche", Fun.HI))
                .clear();

        System.out.println("There are "+map.size()+" players outside of Colorado");


    }
}
