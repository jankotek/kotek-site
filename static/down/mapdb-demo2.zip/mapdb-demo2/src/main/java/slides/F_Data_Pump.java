package slides;

import org.mapdb.*;

import java.io.File;

import java.util.Iterator;
import java.util.Map;
import java.util.Random;
import java.util.UUID;

/**
 * Demostrates how MapDB can import large data set quickly
 */
public class F_Data_Pump {

    final static long SIZE = (long) 1e8;

    final static Random r = new Random();

    public static void main(String[] args) {

        System.out.println("");
        System.out.println("Import started");
        System.out.println("");

        long t = System.currentTimeMillis();

        File store = new File("/tmp/mapdb_data_pump");

        DB db = DBMaker.newFileDB(store)
                .transactionDisable()
                .mmapFileEnable()
                .make();

        Iterator<Fun.Tuple2<Long,UUID>> source = new Iterator<Fun.Tuple2<Long, UUID>>() {

            long counter = SIZE;

            @Override public boolean hasNext() { return counter>0; }

            @Override public Fun.Tuple2<Long, UUID> next() {
                if(counter*100%SIZE==0)
                    System.out.printf("Import in progres, %d %% done\r", 100-100*counter/SIZE);
                return new Fun.Tuple2(counter--, new UUID(r.nextLong(), r.nextLong()));
            }

            @Override public void remove() {}
        };

        Map<Long, UUID> map = db.createTreeMap("idToUUID")
                .keySerializer(BTreeKeySerializer.ZERO_OR_POSITIVE_LONG)
                .valueSerializer(Serializer.UUID)
                .counterEnable()
                .pumpSource(source)
                .make();


        System.out.print("Closing store\r");
        long size = map.size();
        db.close();

        t = System.currentTimeMillis()-t;
        System.out.printf("Imported %,d entries in %,d s\n",size, t/1000);
        System.out.printf("Import rate %,d entries per second\n", 1000*size/t);


    }
}
