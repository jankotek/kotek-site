package slides;

import model.Game;
import model.Player;
import org.mapdb.BTreeMap;
import org.mapdb.Bind;
import org.mapdb.DB;
import org.mapdb.DBMaker;
import static org.mapdb.Fun.*;

import java.util.NavigableSet;

/**
 * Shows secondary keys and 1 to many relationship.
 */
public class D_Secondary_Key {

    public static void main(String[] args) {
        DB db = DBMaker.newMemoryDB()
                .make();

        // primary map
        BTreeMap<Long, Player> players = db.getTreeMap("players");

        //secondary set
        NavigableSet<Tuple2<Long,Game>> playerToGame = db.getTreeSet("playerToGame");

        //create connection between primary and secondary
        Bind.secondaryValues(players, playerToGame, new Function2<Game[], Long, Player>() {
            @Override
            public Game[] run(Long aLong, Player player) {
                return new Game[]{ new Game(player.getName()+" A"), new Game(player.getName()+" B")};
            }
        });

        //fill primary with data
        players.put(1L, new Player("john@example.com", "John Doe"));
        players.put(2L, new Player("brian@example.com", "Brian Ryan"));
        players.put(3L, new Player("neil@example.com", "Neil Smith"));


        //and show all games for Neil Smith
        for(Game game:filter(playerToGame,3L)){
            System.out.println("Neil's game: "+game);
        }

        db.close();
    }
}
